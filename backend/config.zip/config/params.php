<?php
return [
    'adminEmail' => 'auto.mail@fkp-portal.umk.edu.my',
];
