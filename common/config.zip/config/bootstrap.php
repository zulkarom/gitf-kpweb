<?php
Yii::setAlias('@common', dirname(__DIR__));
Yii::setAlias('@frontend', dirname(dirname(__DIR__)) . '/frontend');
Yii::setAlias('@upload', dirname(dirname(__DIR__)) . '/upload');
Yii::setAlias('@backend', dirname(dirname(__DIR__)) . '/backend');
Yii::setAlias('@student', dirname(dirname(__DIR__)) . '/student');
Yii::setAlias('@confsite', dirname(dirname(__DIR__)) . '/confsite');
Yii::setAlias('@console', dirname(dirname(__DIR__)) . '/console');
Yii::setAlias('@student', dirname(dirname(__DIR__)) . '/student');