<?php
return [
    'adminEmail' => 'auto.mail@fkp-portal.umk.edu.my',
    'supportEmail' => 'support@example.com',
    'user.passwordResetTokenExpire' => 3600,
	'faculty_id' => 1,
	'faculty_abbr' => 'FKP'	
];
