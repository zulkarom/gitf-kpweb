<?php

return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=fkpportalumkedu_fkpapps2021',
            'username' => 'root',
            'password' => '',
            'charset' => 'utf8',
        ],
		'view' => [
         'theme' => [
             'pathMap' => [
                '@app/views' => '@app/views'
             ],
         ],
		],
        'urlManager' => [
            'enablePrettyUrl' => false,
             'showScriptName' => false,
            'rules' => [
			'proceedings/download-image' => 'proceedings/download-image',
			'proceedings/download-file' => 'proceedings/download-file',
			'proceedings/<purl>' => 'proceedings/paper',
			
			'<controller>/<action>' => '<controller>', 
			
            //'showScriptName' => false,
            //'rules' => [
			//'product/search-jakim/<cari>/<ty>/<page>/<hdnCounter>' => //'product/search-jakim', 
			//'<controller>/<action>' => '<controller>/<action>',
			//'product/add-product-jakim/<product_name:\w+>/<company:\w+>/<company_id:\w+>/<expired_date:\w+>/<ty:\w+>' => 'product/add-product-jakim',
			
			//'<controller/<id:\d+>'
			//'posts/<year:\d{4}>/<category>' => 'post/index',
			//'posts' => 'post/index',
			//'post/<id:\d+>' => 'post/view',
			
            ],
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'viewPath' => '@common/mail',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            'useFileTransport' => true,
        ],
		
		'mailqueue' => [
            'class' => 'nterms\mailqueue\MailQueue',
			'table' => '{{%mail_queue}}',
			'mailsPerRound' => 10,
			'maxAttempts' => 3,
			'transport' => [
				'class' => 'Swift_SmtpTransport',
				'host' => 'localhost',
				'username' => 'username',
				'password' => 'password',
				'port' => '587',
				'encryption' => 'tls',
			],
        ],
    ],
];
